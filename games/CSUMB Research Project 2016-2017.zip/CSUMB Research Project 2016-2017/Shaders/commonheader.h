#pragma once

#define NUM_THREADS 1024 //max 1024
#define NUM_THREADSX 8
#define NUM_THREADSY 128
#define NUM_THREADSXY 1024 //max 1024

#define VERTCOUNT 60
#define INSTCOUNT 32
#define STEPSIZE .5

#define SHADOWMAPXYSIZE 4096

#define WINRESX 1920
#define WINRESY 1080

#define MAXTEX1DSIZE 16384
#define BUFFERSIZE_VFL 2000000
#define BUFFERSIZE_NB 52000000
#define BRICKPOOLSIZE 510
#define COUNTSIZE 50			//see shaderheader.fxh for more info

//	****				OCTREE ELEMENT		*****

#define OCT_BRICKINDEX		8
#define OCT_BINARYINDEX		9
#define OCT_PARENT			10
#define OCT_ELEMENTSIZE		11		//8 kids index, brickbuff, binary index       ... 0-7,8,9     //see shaderheader.fxh for more info

#define OCT_BRICKINDEX_LL	0
#define OCT_BINARYINDEX_LL	1
#define OCT_RED_LL			2
#define OCT_GREENBLUE_LL	3
#define OCT_PIXELCOUNT_LL	4
#define OCT_PARENT_LL		5
#define OCT_ELEMENTSIZE_LL	6	//brickbuffer, binary index, r,g,b,pixelcount ... 0,1,2,3,4,5 //see shaderheader.fxh for more info

#define OCT_BINARYINDEX_MASK_VISITED		1073741824u
#define OCT_BINARYINDEX_RESET_MASK_VISITED	1073741823u //2147483647u

#define VFL2OCT_COLORMATCH 0.05


//		*****		Count[50 element array]			*****
#define COUNT_VFL 0						//	[0] - next vfl index / total vfl count
#define COUNT_START_CURR_OCT_LVL 1		//	[1] - beginning of current octree level
#define COUNT_OCT_COUNT_STATIC 2		//	[2] - next octree index / total octree array element count - static
#define COUNT_OCT_SUB_COUNT 3			//	[3] - total octree subdivision count
#define COUNT_OCT_COUNT_DYNAMIC 4		//	[4] - next octree index / total octree array element count - dynamic
#define COUNT_PIX_COUNT 5				//	[5] - total pixel count
#define COUNT_BB_COUNT 6				//	[6] - next brickbuffer index / total brickbuffer count
//	[7-9] - free, use for debugbuffer
#define OCT_LVL_COUNT 10 //octree count list offset -	[10 - 19] total octree array element count for each level
#define BB_LVL_COUNT 20 //brick buffer count list offset - [20 - 29] total brickbuffer count for each level
#define WL_LVL_COUNT 30 //worklist count list offset - [30 - 39] total workonlist count for each level






static const unsigned int maxlevel = 8;
static const float vxarea = 256;
static const int brickpoolsector = (BRICKPOOLSIZE*BRICKPOOLSIZE*BRICKPOOLSIZE) / (3 * 3 * 3 * 4); // 1/4 of the total number of 3x3x3 volumes in the brick pool
static const float PI = 3.14159265f;
static const unsigned int binary_level_mask[11] = { 0x0, 0x100401, 0x300C03, 0x701C07, 0xF03C0F, 0x1F07C1F, 0x3F0FC3F, 0x7F1FC7F, 0xFF3FCFF, 0x1FF7FDFF, 0x3FFFFFFF};
static const unsigned int binary_idx_mask[3] = { 0x100000, 0x400, 0x1 };

// Front/Middle/Back, Up/Middle/Down, Left/Middle/Right
#define NB_COUNT 26

// z,y,x
#define NB_B_U_L 0
#define NB_B_U_M 1
#define NB_B_U_R 2
#define NB_B_M_L 3
#define NB_B_M_M 4
#define NB_B_M_R 5
#define NB_B_D_L 6
#define NB_B_D_M 7
#define NB_B_D_R 8

#define NB_M_U_L 9
#define NB_M_U_M 10
#define NB_M_U_R 11
#define NB_M_M_L 12
#define NB_M_M_R 13
#define NB_M_D_L 14
#define NB_M_D_M 15
#define NB_M_D_R 16

#define NB_F_U_L 17
#define NB_F_U_M 18
#define NB_F_U_R 19
#define NB_F_M_L 20
#define NB_F_M_M 21
#define NB_F_M_R 22
#define NB_F_D_L 23
#define NB_F_D_M 24
#define NB_F_D_R 25